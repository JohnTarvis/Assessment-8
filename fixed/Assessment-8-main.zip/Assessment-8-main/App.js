import React from "react";
import MadLib from "./MadLib";

function App() {
  return (
    <div className="App">
      <MadLib />
    </div>
  );
}

export default App;
